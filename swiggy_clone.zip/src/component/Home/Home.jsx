import React from 'react'
import Main from '../main/Main'

const Home = () => {
  return (
    <div>
        <Main />
    </div>
  )
}

export default Home