import React from 'react'

const Error = () => {
  return (
    <div>
        <img style={{display: 'flex', margin: '150px auto', width:'60%'}} src="https://serpstat.com/img/blog/how-to-create-a-5xx-error-page/1564678552pPwxC6P.png" />
    </div>
  )
}

export default Error

